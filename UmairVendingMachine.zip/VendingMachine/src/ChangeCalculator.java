/*
Author : Muhammad Umair
Description: This program calculates how many quarters, dimes and nickels 
should be returned when an item which is under a dollar is purchased.
*/
import java.io.InputStream;
import java.util.Scanner;


public class ChangeCalculator {
    

public static void main(String []   args) {

    System.out.println( " Hi there! Welcome to the vending machine program! " );
    System.out.println ( "Every thing in this machine costs less than one dollar ");
    System.out.println( " I will tell you how many quarters, dimes and nickels "
    + " you are supposed to recieve back" );
    
    Scanner vendingMachine = new Scanner(System.in);
    double cost = vendingMachine.nextDouble(); 
   
    
    double change = (double) (1.00 - cost);
    int quarters = (int) (change/.25);
    
    
    double newChange = (double) ( change - (quarters * .25));
    int dimes = (int) (newChange/.10);
    
    double nickelChange = (double)( newChange - (dimes * .10));
    int nickels = (int) (nickelChange/.05);
    
    
    System.out.println ( "Your change is " + quarters + " quarters" );
    System.out.println ( dimes + " dimes");
    System.out.println ( nickels + " nickels");
     
            
    
}  
}
